# CryptoPay Enterprise

Plataforma Web + PWA para conexão de carteiras cripto, consulta de saldos multi-chain,
conversão para BRL e dashboard financeiro.

> ⚠️ **Aviso regulatório:** este projeto é um esqueleto técnico/educacional. Qualquer
> funcionalidade de conversão cripto → fiat ou liquidação de fundos requer, para uso em
> produção no Brasil, conformidade com KYC/AML e regulamentação do Bacen/CVM, além de
> integração com um provedor de liquidação devidamente autorizado. Nenhuma liquidação real
> é processada por este código.

## Stack

| Camada      | Tecnologias |
|-------------|-------------|
| Frontend    | Next.js, React, TypeScript, Tailwind CSS, PWA, TanStack Query, Zustand |
| Backend     | NestJS, Prisma ORM, PostgreSQL, Redis, JWT, Swagger |
| Blockchain  | WalletConnect v2, Ethers.js, BlockCypher (BTC), 1RPC (ETH/Polygon/BNB) |
| Infra       | Docker Compose, GitHub Actions, Netlify (frontend), Railway (backend) |

## Estrutura do monorepo

```
apps/
  web/      → Next.js PWA (usuário final)
  api/      → NestJS REST API
  admin/    → Next.js painel administrativo
packages/
  auth/         → lógica de autenticação compartilhada (JWT, 2FA, sessão)
  ui/            → componentes de UI compartilhados
  wallet/        → integração WalletConnect v2
  blockchain/    → clientes de blockchain (Ethers.js, BlockCypher)
  qr/            → scanner/parser de QR Code
  shared/        → tipos, schemas (zod) e utilitários compartilhados
```

## Pré-requisitos

- Node.js ≥ 20
- pnpm ≥ 9
- Docker e Docker Compose

## Setup local

```bash
cp .env.example .env
pnpm install
docker compose up -d postgres redis
pnpm --filter=api prisma:migrate
pnpm dev
```

- Web: http://localhost:3000
- Admin: http://localhost:3002
- API: http://localhost:3001
- Swagger: http://localhost:3001/docs

## Scripts principais

| Comando | Descrição |
|---|---|
| `pnpm dev` | Sobe todas as apps em modo desenvolvimento (via Turborepo) |
| `pnpm build` | Build de produção de todas as apps/pacotes |
| `pnpm lint` | Lint em todo o monorepo |
| `pnpm test` | Testes unitários em todo o monorepo |
| `pnpm test:e2e` | Testes de integração/e2e |
| `pnpm format` | Formata o código com Prettier |

## Roadmap de módulos

- [x] Estrutura do monorepo + configs base (lint, prettier, husky, commitlint, docker, CI)
- [ ] Backend: autenticação (cadastro, login, refresh token, 2FA, recuperação de senha)
- [ ] Backend: módulos de carteira, saldo, transações, cotação, notificações, auditoria
- [ ] Frontend web: dashboard, conexão de carteira, scanner QR, histórico, PWA
- [ ] Painel administrativo
- [ ] Testes de integração e e2e
- [ ] Documentação Swagger completa

## Licença

Uso interno / educacional.
