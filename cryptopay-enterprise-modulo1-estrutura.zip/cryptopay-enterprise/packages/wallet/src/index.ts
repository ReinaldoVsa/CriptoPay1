// Ponto de entrada do pacote @cryptopay/wallet
// A implementação completa deste pacote será entregue no módulo correspondente.
export {};
