// Ponto de entrada do pacote @cryptopay/qr
// A implementação completa deste pacote será entregue no módulo correspondente.
export {};
