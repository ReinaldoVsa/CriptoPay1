// Ponto de entrada do pacote @cryptopay/auth
// A implementação completa deste pacote será entregue no módulo correspondente.
export {};
