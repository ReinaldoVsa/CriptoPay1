// Ponto de entrada do pacote @cryptopay/ui
// A implementação completa deste pacote será entregue no módulo correspondente.
export {};
