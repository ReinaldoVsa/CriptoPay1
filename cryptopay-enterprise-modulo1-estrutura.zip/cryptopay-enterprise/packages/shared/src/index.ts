// Ponto de entrada do pacote @cryptopay/shared
// A implementação completa deste pacote será entregue no módulo correspondente.
export {};
