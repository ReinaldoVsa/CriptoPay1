// Ponto de entrada do pacote @cryptopay/blockchain
// A implementação completa deste pacote será entregue no módulo correspondente.
export {};
